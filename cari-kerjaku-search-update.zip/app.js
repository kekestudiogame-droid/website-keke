const SUPABASE_URL ="https://ksqrimmecpriyepsuclc.supabase.co/rest/v1/"
const SUPABASE_KEY = "sb_publishable_xvPQL9oniSRwZoqmSc5W4A_NS9ldWIL"

const supabaseHeaders = {
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${SUPABASE_KEY}`,
  "Content-Type": "application/json"
};
const SUPABASE_JOBS_URL = `${SUPABASE_URL}jobs`;

const jobs = [
  {title:'Frontend Developer', company:'Teknologi Nusantara', location:'Jakarta', category:'Teknologi', type:'Full-time', salary:'Rp 8–12 juta / bulan', initials:'TN'},
  {title:'Backend Developer', company:'Solusi Digital Indonesia', location:'Bandung', category:'Teknologi', type:'Full-time', salary:'Rp 9–14 juta / bulan', initials:'SD'},
  {title:'Full Stack Developer', company:'Nusantara Tech', location:'Jakarta', category:'Teknologi', type:'Full-time', salary:'Rp 10–16 juta / bulan', initials:'NT'},
  {title:'Software Engineer', company:'Digital Solusi', location:'Surabaya', category:'Teknologi', type:'Full-time', salary:'Rp 9–15 juta / bulan', initials:'DS'},
  {title:'Mobile Developer', company:'Aplikasi Kita', location:'Jakarta', category:'Teknologi', type:'Full-time', salary:'Rp 8–14 juta / bulan', initials:'AK'},
  {title:'Web Developer', company:'Karya Teknologi', location:'Yogyakarta', category:'Teknologi', type:'Full-time', salary:'Rp 7–12 juta / bulan', initials:'KT'},
  {title:'Data Analyst', company:'Data Indonesia', location:'Bandung', category:'Teknologi', type:'Full-time', salary:'Rp 8–13 juta / bulan', initials:'DI'},
  {title:'Data Scientist', company:'Smart Data Nusantara', location:'Jakarta', category:'Teknologi', type:'Full-time', salary:'Rp 12–20 juta / bulan', initials:'SN'},
  {title:'IT Support', company:'Prima Teknologi', location:'Semarang', category:'Teknologi', type:'Full-time', salary:'Rp 5–8 juta / bulan', initials:'PT'},
  {title:'Network Engineer', company:'Jaringan Indonesia', location:'Surabaya', category:'Teknologi', type:'Full-time', salary:'Rp 7–12 juta / bulan', initials:'JI'},
  {title:'QA Tester', company:'Software Prima', location:'Jakarta', category:'Teknologi', type:'Full-time', salary:'Rp 6–10 juta / bulan', initials:'SP'},
  {title:'Digital Marketing Specialist', company:'Maju Bersama', location:'Jakarta', category:'Marketing', type:'Full-time', salary:'Rp 6–9 juta / bulan', initials:'MB'},
  {title:'Marketing Executive', company:'Sukses Indonesia', location:'Bandung', category:'Marketing', type:'Full-time', salary:'Rp 6–10 juta / bulan', initials:'SI'},
  {title:'Marketing Staff', company:'Nusantara Jaya', location:'Surabaya', category:'Marketing', type:'Full-time', salary:'Rp 5–8 juta / bulan', initials:'NJ'},
  {title:'SEO Specialist', company:'Media Digital', location:'Jakarta', category:'Marketing', type:'Remote', salary:'Rp 7–11 juta / bulan', initials:'MD'},
  {title:'Content Marketing', company:'Kreatif Indonesia', location:'Yogyakarta', category:'Marketing', type:'Full-time', salary:'Rp 5–9 juta / bulan', initials:'KI'},
  {title:'Social Media Specialist', company:'Ruang Kreatif', location:'Yogyakarta', category:'Marketing', type:'Full-time', salary:'Rp 5–8 juta / bulan', initials:'RK'},
  {title:'Brand Marketing Specialist', company:'Mitra Bisnis', location:'Jakarta', category:'Marketing', type:'Full-time', salary:'Rp 7–12 juta / bulan', initials:'MB'},
  {title:'Staff Administrasi', company:'Prima Nusantara', location:'Surabaya', category:'Administrasi', type:'Full-time', salary:'Rp 4–6 juta / bulan', initials:'PN'},
  {title:'Admin Gudang', company:'Logistik Jaya', location:'Bekasi', category:'Administrasi', type:'Full-time', salary:'Rp 4–7 juta / bulan', initials:'LJ'},
  {title:'Admin Finance', company:'Keuangan Maju', location:'Jakarta', category:'Administrasi', type:'Full-time', salary:'Rp 5–8 juta / bulan', initials:'KM'},
  {title:'Admin HR', company:'Sumber Daya Indonesia', location:'Bandung', category:'Administrasi', type:'Full-time', salary:'Rp 5–8 juta / bulan', initials:'SD'},
  {title:'Customer Service', company:'Layanan Kita', location:'Jakarta', category:'Administrasi', type:'Full-time', salary:'Rp 4–7 juta / bulan', initials:'LK'},
  {title:'Receptionist', company:'Hotel Nusantara', location:'Denpasar', category:'Administrasi', type:'Full-time', salary:'Rp 4–6 juta / bulan', initials:'HN'},
  {title:'Sekretaris', company:'Perusahaan Jaya', location:'Jakarta', category:'Administrasi', type:'Full-time', salary:'Rp 5–9 juta / bulan', initials:'PJ'},
  {title:'Accounting Staff', company:'Akuntansi Indonesia', location:'Jakarta', category:'Keuangan', type:'Full-time', salary:'Rp 5–9 juta / bulan', initials:'AI'},
  {title:'Finance Staff', company:'Mitra Finansial', location:'Surabaya', category:'Keuangan', type:'Full-time', salary:'Rp 5–9 juta / bulan', initials:'MF'},
  {title:'Tax Staff', company:'Konsultan Pajak Nusantara', location:'Jakarta', category:'Keuangan', type:'Full-time', salary:'Rp 6–10 juta / bulan', initials:'KP'},
  {title:'Auditor', company:'Audit Profesional', location:'Bandung', category:'Keuangan', type:'Full-time', salary:'Rp 7–12 juta / bulan', initials:'AP'},
  {title:'UI/UX Designer', company:'Karya Digital', location:'Remote', category:'Desain', type:'Remote', salary:'Rp 7–10 juta / bulan', initials:'KD'},
  {title:'Graphic Designer', company:'Studio Kreatif', location:'Jakarta', category:'Desain', type:'Full-time', salary:'Rp 5–9 juta / bulan', initials:'SK'},
  {title:'Illustrator', company:'Visual Nusantara', location:'Bandung', category:'Desain', type:'Full-time', salary:'Rp 5–9 juta / bulan', initials:'VN'},
  {title:'Video Editor', company:'Media Kreatif', location:'Jakarta', category:'Desain', type:'Full-time', salary:'Rp 5–9 juta / bulan', initials:'MK'},
  {title:'Content Creator', company:'Konten Indonesia', location:'Yogyakarta', category:'Desain', type:'Full-time', salary:'Rp 5–9 juta / bulan', initials:'KI'},
  {title:'Sales Executive', company:'Penjualan Jaya', location:'Jakarta', category:'Penjualan', type:'Full-time', salary:'Rp 5–10 juta / bulan', initials:'PJ'},
  {title:'Sales Representative', company:'Maju Sejahtera', location:'Surabaya', category:'Penjualan', type:'Full-time', salary:'Rp 5–9 juta / bulan', initials:'MS'},
  {title:'Business Development', company:'Bisnis Indonesia', location:'Bandung', category:'Penjualan', type:'Full-time', salary:'Rp 7–13 juta / bulan', initials:'BI'},
  {title:'Staff Gudang', company:'Gudang Nusantara', location:'Bekasi', category:'Operasional', type:'Full-time', salary:'Rp 4–7 juta / bulan', initials:'GN'},
  {title:'Warehouse Supervisor', company:'Logistik Indonesia', location:'Tangerang', category:'Operasional', type:'Full-time', salary:'Rp 6–10 juta / bulan', initials:'LI'},
  {title:'Purchasing Staff', company:'Belanja Perusahaan', location:'Jakarta', category:'Operasional', type:'Full-time', salary:'Rp 5–9 juta / bulan', initials:'BP'},
  {title:'Driver', company:'Transportasi Jaya', location:'Jakarta', category:'Operasional', type:'Full-time', salary:'Rp 4–7 juta / bulan', initials:'TJ'},
  {title:'Kurir', company:'Kirim Cepat', location:'Surabaya', category:'Operasional', type:'Full-time', salary:'Rp 4–7 juta / bulan', initials:'KC'},
  {title:'Guru', company:'Sekolah Nusantara', location:'Bandung', category:'Pendidikan', type:'Full-time', salary:'Rp 4–8 juta / bulan', initials:'SN'},
  {title:'Tutor', company:'Pendidikan Pintar', location:'Jakarta', category:'Pendidikan', type:'Part-time', salary:'Rp 3–7 juta / bulan', initials:'PP'},
  {title:'Dosen', company:'Kampus Indonesia', location:'Yogyakarta', category:'Pendidikan', type:'Full-time', salary:'Rp 7–12 juta / bulan', initials:'KI'},
  {title:'Human Resources Staff', company:'SDM Nusantara', location:'Jakarta', category:'SDM', type:'Full-time', salary:'Rp 5–9 juta / bulan', initials:'SN'},
  {title:'Recruitment Specialist', company:'Talenta Indonesia', location:'Bandung', category:'SDM', type:'Full-time', salary:'Rp 6–11 juta / bulan', initials:'TI'},
  {title:'HR Business Partner', company:'Perusahaan Maju', location:'Jakarta', category:'SDM', type:'Full-time', salary:'Rp 9–15 juta / bulan', initials:'PM'},
  {title:'Perawat', company:'Klinik Sehat', location:'Jakarta', category:'Kesehatan', type:'Full-time', salary:'Rp 5–9 juta / bulan', initials:'KS'},
  {title:'Apoteker', company:'Apotek Indonesia', location:'Surabaya', category:'Kesehatan', type:'Full-time', salary:'Rp 6–10 juta / bulan', initials:'AI'}
];

const jobsGrid = document.querySelector("#jobsGrid");
const emptyState = document.querySelector("#emptyState");
const jobCount = document.querySelector("#jobCount");
const categoryFilter = document.querySelector("#categoryFilter");
const keyword = document.querySelector("#keyword");
const locationInput = document.querySelector("#location");

const jobSuggestions = ['Accounting Staff', 'Admin Finance', 'Admin Gudang', 'Admin HR', 'Administrasi', 'Apoteker', 'Auditor', 'Backend Developer', 'Brand Marketing Specialist', 'Business Development', 'Content Creator', 'Content Marketing', 'Customer Service', 'Data Analyst', 'Data Scientist', 'Desain', 'Digital Marketing Specialist', 'Dosen', 'Driver', 'Finance Staff', 'Frontend Developer', 'Full Stack Developer', 'Graphic Designer', 'Guru', 'HR Business Partner', 'Human Resources Staff', 'IT Support', 'Illustrator', 'Kesehatan', 'Keuangan', 'Kurir', 'Marketing', 'Marketing Executive', 'Marketing Staff', 'Mobile Developer', 'Network Engineer', 'Operasional', 'Pendidikan', 'Penjualan', 'Perawat', 'Purchasing Staff', 'QA Tester', 'Receptionist', 'Recruitment Specialist', 'SDM', 'SEO Specialist', 'Sales Executive', 'Sales Representative', 'Sekretaris', 'Social Media Specialist', 'Software Engineer', 'Staff Administrasi', 'Staff Gudang', 'Tax Staff', 'Teknologi', 'Tutor', 'UI/UX Designer', 'Video Editor', 'Warehouse Supervisor', 'Web Developer'];
const citySuggestions = ['Jakarta', 'Bandung', 'Surabaya', 'Yogyakarta', 'Semarang', 'Medan', 'Makassar', 'Denpasar', 'Bekasi', 'Tangerang', 'Bogor', 'Depok', 'Malang', 'Palembang', 'Balikpapan', 'Batam', 'Remote', 'Indonesia'];

document.querySelector("#daftar-pekerjaan").innerHTML =
  jobSuggestions.map(x => `<option value="${x}"></option>`).join("");
document.querySelector("#daftar-kota").innerHTML =
  citySuggestions.map(x => `<option value="${x}"></option>`).join("");

function renderJobs(list = jobs){
  jobsGrid.innerHTML = "";
  jobCount.textContent = list.length;
  emptyState.classList.toggle("hidden", list.length !== 0);
  list.forEach((job, i) => {
    const card = document.createElement("article");
    card.className = "job-card";
    card.innerHTML = `
      <div class="job-top">
        <div class="company-logo">${job.initials}</div>
        <span class="pill">${job.type}</span>
      </div>
      <h3>${job.title}</h3>
      <div class="company">${job.company}</div>
      <div class="job-meta"><span>📍 ${job.location}</span><span>▣ ${job.category}</span></div>
      <div class="salary">${job.salary}</div>
      <div class="job-actions">
        <button data-details="${i}">Lihat detail</button>
        <button data-apply="${i}">Lamar →</button>
      </div>`;
    jobsGrid.appendChild(card);
  });
}

function filterJobs(){
  const q = keyword.value.trim().toLowerCase();
  const loc = locationInput.value.trim().toLowerCase();
  const cat = categoryFilter.value;

  const filtered = jobs.filter(j => {
    const text = `${j.title} ${j.company} ${j.category}`.toLowerCase();
    const locationText = j.location.toLowerCase();
    return (cat === "all" || j.category === cat) &&
      (!q || text.includes(q)) &&
      (!loc || locationText.includes(loc) || (loc === "indonesia" && j.location === "Remote"));
  });

  renderJobs(filtered);
  document.querySelector("#jobs").scrollIntoView({behavior:"smooth"});
}

document.querySelector("#searchForm").addEventListener("submit", e => { e.preventDefault(); filterJobs(); });
categoryFilter.addEventListener("change", filterJobs);

document.querySelectorAll(".quick-tags button").forEach(btn =>
  btn.addEventListener("click", () => {
    keyword.value = btn.dataset.keyword;
    filterJobs();
  })
);

jobsGrid.addEventListener("click", e => {
  const details = e.target.closest("[data-details]");
  const apply = e.target.closest("[data-apply]");
  const idx = Number((details || apply)?.dataset[details ? "details" : "apply"]);
  if (!Number.isInteger(idx)) return;
  const job = jobs[idx];

  if (apply) {
    openModal("Lamaran", `Kamu memilih ${job.title} di ${job.company}. Fitur pengiriman lamaran akan diaktifkan setelah backend dan akun pengguna terhubung.`);
  } else {
    openModal(job.title, `${job.company} · ${job.location}\n\nKategori: ${job.category}\nTipe: ${job.type}\nGaji: ${job.salary}\n\nIni adalah data demo untuk prototype Cari Kerjaku ID.`);
  }
});

const modal = document.querySelector("#authModal");
const modalTitle = document.querySelector("#modalTitle");
const modalText = document.querySelector("#modalText");
const authForm = document.querySelector("#authForm");
let isRegister = false;

function openModal(title, text){
  modalTitle.textContent = title;
  modalText.textContent = text;
  authForm.classList.toggle("hidden", title !== "Masuk" && title !== "Daftar");
  document.querySelector(".switch-auth").classList.toggle("hidden", title !== "Masuk" && title !== "Daftar");
  modal.classList.remove("hidden");
}

document.querySelector("#loginBtn").addEventListener("click", () => {
  isRegister = false;
  modalTitle.textContent = "Masuk";
  modalText.textContent = "Prototype akun. Backend akan dihubungkan pada tahap berikutnya.";
  authForm.classList.remove("hidden");
  document.querySelector(".switch-auth").classList.remove("hidden");
  modal.classList.remove("hidden");
});

document.querySelector("#registerBtn").addEventListener("click", () => {
  isRegister = true;
  modalTitle.textContent = "Daftar";
  modalText.textContent = "Prototype pendaftaran. Backend akan dihubungkan pada tahap berikutnya.";
  authForm.classList.remove("hidden");
  document.querySelector(".switch-auth").classList.remove("hidden");
  modal.classList.remove("hidden");
});

document.querySelector("#switchAuth").addEventListener("click", () => {
  isRegister = !isRegister;
  modalTitle.textContent = isRegister ? "Daftar" : "Masuk";
  modalText.textContent = isRegister ? "Prototype pendaftaran. Backend akan dihubungkan pada tahap berikutnya." : "Prototype akun. Backend akan dihubungkan pada tahap berikutnya.";
  document.querySelector("#switchAuth").textContent = isRegister ? "Masuk" : "Daftar";
});

document.querySelector("#closeModal").addEventListener("click", () => modal.classList.add("hidden"));
modal.addEventListener("click", e => { if(e.target === modal) modal.classList.add("hidden"); });

authForm.addEventListener("submit", async e => {
  e.preventDefault();
  const emailInput = document.querySelector('input[type="email"]');
  const passwordInput = document.querySelector('input[type="password"]');
  const email = emailInput.value.trim();
  const password = passwordInput.value;
  const authUrl = SUPABASE_URL.replace("/rest/v1/", "/auth/v1/");

  try {
    const response = await fetch(
      isRegister ? `${authUrl}/signup` : `${authUrl}/token?grant_type=password`,
      {
        method: "POST",
        headers: { apikey: SUPABASE_KEY, "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      }
    );
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.msg || data.error_description || data.message || "Gagal");
    }

    if (isRegister) {
      alert("Pendaftaran berhasil! Silakan masuk menggunakan email dan password tadi.");
      isRegister = false;
      modalTitle.textContent = "Masuk";
      modalText.textContent = "Masukkan email dan password untuk masuk.";
      document.querySelector("#switchAuth").textContent = "Daftar";
    } else {
      localStorage.setItem("cariKerjakuAccessToken", data.access_token || "");
      localStorage.setItem("cariKerjakuUser", JSON.stringify(data.user || {}));
      alert("Login berhasil!");
      modal.classList.add("hidden");
    }
  } catch (error) {
    alert("Gagal: " + error.message);
  }
});

renderJobs(jobs);
document.querySelector("#year").textContent = new Date().getFullYear();
